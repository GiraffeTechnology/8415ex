"""Install reviewed EX source only. Does not start a service or modify state."""
import argparse, hashlib, pathlib, sys
p=argparse.ArgumentParser();p.add_argument('--target',required=True);args=p.parse_args()
archive=pathlib.Path(__file__).resolve().with_name('source.zip')
data=archive.read_bytes()
if hashlib.sha256(data).hexdigest()!='d274c0c6718717c431d38328637ef91f71f59eaeeaeac2ec7fd34201d8b39483':raise SystemExit('source archive digest mismatch')
sys.path.insert(0,str(archive))
from exchange.service_install import install_source
result=install_source(data,sha256='d274c0c6718717c431d38328637ef91f71f59eaeeaeac2ec7fd34201d8b39483',tree='dbb6eb8381be6814ee6881484642e4a6565d2ab6',commit='8fababe4febc344ad8f07db54a44cc2c0714bedd',target=args.target)
print('Source installed; service not started; original state unchanged.')
