"""Install reviewed EX source only. Does not start a service or modify state."""
import argparse, hashlib, pathlib, sys
p=argparse.ArgumentParser();p.add_argument('--target',required=True);args=p.parse_args()
archive=pathlib.Path(__file__).resolve().with_name('source.zip')
data=archive.read_bytes()
if hashlib.sha256(data).hexdigest()!='5df492245dc6d74972e8a6bbfc5b345a9c31f796636176513272f3f9a0603b63':raise SystemExit('source archive digest mismatch')
sys.path.insert(0,str(archive))
from exchange.service_install import install_source
result=install_source(data,sha256='5df492245dc6d74972e8a6bbfc5b345a9c31f796636176513272f3f9a0603b63',tree='afba4cd26719ad6a014cc7a6e4fc71c500389c1f',commit='ec35f24212f432d1df78d12c75a39a8212dcb826',target=args.target)
print('Source installed; service not started; original state unchanged.')
